Feet to Centimeter Changer Pro
-------------------------------------------------------------

Author: Mohammad Sajjad Baqri
Website: mohammadsajjadbaqri.github.io/index
Version: 1.0
-------------------------------------------------------------

How to Use?
Copy the 'setup.jar' file in a save location and create a shortcut on the desktop. Rename the setup file from 'setup.jar' to 'Feet to Centimeter Changer Pro.jar'
Double click for execution.
-------------------------------------------------------------

ERROR!
1. If you are unable to open the setup file, you need to install the latest version of Java.
   You can download it from:-
   https://www.oracle.com/java/technologies/downloads/
2. If you are still unable to open it, delete all the versions of Java and install thr latest version of JDK from the link above.
3. If you're still facing an error, contact me on:-
   https://mohammadsajjadbaqri.github.io/index/contact-me
-------------------------------------------------------------

NOTE:-
All rights are reserved. Republishing this app is not allowed without the author's permission.